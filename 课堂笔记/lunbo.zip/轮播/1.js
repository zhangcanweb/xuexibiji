$(document).ready(function(){ 
	var n=0;  
	$("#banner_list a:not(:first-child)").hide(); 
	$("#banner li").click(function(){ 
		var i=$(this).text()-1;
		n=i; 
		$("#banner_list a").filter(":visible").fadeOut(500)
						   .parent().children().eq(n).fadeIn(1000); 
		$(this).css({"background":"#be2424",'color':'#000'})
			   .siblings().css({"background":"#6f4f67",'color':'#fff'}); 
	}); 
	setInterval(function(){
	var count=$("#banner_list a").length;
	if(n>(count-1)){
		n=0;
	}else{
		n++;
	}
	$("#banner li").eq(n).trigger('click'); 
},3000); 
}) 
